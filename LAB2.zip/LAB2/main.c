#include <stdio.h>
#include <stdbool.h>

unsigned int konwenterGraya(unsigned int num) {
    return num ^ (num >> 1);
}
unsigned int grayToDecimal(unsigned int gray) {
    unsigned int binary = 0;

    while (gray > 0) {
        binary ^= gray;
        gray >>= 1;
    }
    return binary;
}
void printBinary(unsigned int n, int a) {
    for (int i = a-1; i >= 0; i--) { // Wy�wietla 4 bity
        printf("%d", (n >> i) & 1);
    }
}

int main() {
    // kod graya
    /*
    unsigned int liczba;

    printf("Podaj liczbe dziesietna (0-255): ");
    scanf("%u", &liczba);

    unsigned int kodGraya = konwenterGraya(liczba);

    printf("Liczba (Dec): %u\n", liczba);
    printf("Liczba (Bin): ");
    printBinary(liczba,8);
    printf("\nKod Graya:   ");
    printBinary(kodGraya,8);

    unsigned int gray = 0b1100; // Przyk�ad: 12 w kodzie Graya (odp. 10 w dziesi�tnym)
    unsigned int decimal = grayToDecimal(gray);

    printf("\nKod Graya: %u, Wartosc dziesietna: %u\n", gray, decimal);
    */

    return 0;
}
