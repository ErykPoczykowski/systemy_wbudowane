#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

float sumowanie(float a,float b)
{
    return a+b;
}

int mnozenie(int a,int b,int c)
{

    return a*b*c;
}
void czy_dodatnia(float b)
{
    if(b > 0)
    {
        printf("liczba %f jest dodania\n",b);
    }
    else
    {
        printf("liczba %f nie jest dodatnia\n",b);
    }
}

int wyswietl_tablice(int tablica[],int size)
{
    printf("{");
    for(int i = 0;i<size;i++)
    {
        printf("%d, ",tablica[i]);
    }
    printf("}\n");
}

void czytaj_liczby()
{
    int liczba, suma = 0;
    do
    {
        printf("podaj liczbe, liczba 0 konczy dzialanie\n");
        scanf("%d",&liczba);
        suma +=liczba;
    } while(liczba!=0);
    printf("suma to %d",suma);
}

void kalkulator(int a, int b, char znak)
{
    switch(znak)
    {
    case '+':
        printf("wynik kalukatora to %d\n",a+b);
        break;
    case '-':
        printf("wynik kalukatora to %d\n",a-b);
        break;
    case '*':
        printf("wynik kalukatora to %d\n",a*b);
        break;
    case '/':
        printf("wynik kalukatora to %d\n",a/b);
        break;
    default:
        printf("operacja nieznana");
    }
}
// zad 1.1
int silnia(int n)
{
    int suma = 1;
    for(int i = n;i >1;i--)
    {
        suma *=i;
    }
    return suma;
}
// zad 1.2
int parzyste(int start,int end)
{
    int suma = 0;
    for(int i = start;i <= end;i++)
    {
        if(i%2==0)
        {
           suma +=i;
        }
    }
    return suma;
}
// zad 1.3
void tabliczka(int n)
{
    for(int i = 1;i<=n;i++)
    {
        printf("\n");
        for(int j = 1;j<=n;j++)
        {
            printf("%d|",j*i);
        }
    }
}
// zad 2.1
int suma(int n)
{
    int suma = 0;
    while(n%10 != 0)
    {
        suma += (n%10);
        n -= (n%10);
        n /=10;
        printf("\n%d, ",suma);
    }
    return suma;
}

int main()
{
    /*
    int a = 10;
    float b = 3.14;

    char c = 'a';
    printf("zmienna a = %d\n",a);
    printf("zmienna b = %f\n",b);
    printf("zmienna c = %c\n",c);

    float wynik = a+b;
    printf("wynik to %f\n",wynik);

    int tablica[3] = {1,2,3};
    int *ptr = tablica;
    printf("Pierwszy element tablicy = %d\n",*ptr);

    printf("wynik funkcji = %f\n",sumowanie(a,b));

    int wynik_mnozenia = mnozenie(10,10,10);
    printf("wynik mnozenia funkcji = %d\n",wynik_mnozenia);

    czy_dodatnia(-5);
    wyswietl_tablice(tablica,3);
    //czytaj_liczby();
    kalkulator(10,5,'/');
    */
    // zad 1
    printf("\nsilnia = %d",silnia(4));
    printf("\nparzyste = %d",parzyste(5,10));
    tabliczka(10);
    printf("\nsuma = %d",suma(123));


    return 0;
}
